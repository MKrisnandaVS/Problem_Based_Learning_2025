// js/core.js

// --- KONFIGURASI DAN STATE GLOBAL ---
const API_BASE_URL = "http://localhost:8000";
const USD_TO_IDR = 15750; // Example rate
const pageTitles = {
  home: "Home Dashboard",
  clustering: "Stock Clustering",
  forecasting: "Stock Forecasting",
  screening: "Stock Screening",
};

// --- FUNGSI UTILITAS (DI-EXPORT) ---
export const config = { API_BASE_URL, USD_TO_IDR };

export function showLoading(show) {
  document.getElementById("loading").classList.toggle("active", show);
}

// Menggunakan metode toLocaleString yang lebih standar dan andal
export function formatPriceIndonesian(value) {
  if (value === null || value === undefined || isNaN(value)) return "N/A";
  return value.toLocaleString("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).replace("Rp", "").trim();
}

export function formatVolume(value) {
    if (value === null || value === undefined || isNaN(value)) return "N/A";
    if (value >= 1.0e9) return (value / 1.0e9).toFixed(1) + "B";
    if (value >= 1.0e6) return (value / 1.0e6).toFixed(1) + "M";
    if (value >= 1.0e3) return (value / 1.0e3).toFixed(1) + "K";
    return value.toLocaleString();
}

export function formatPercentage(value) {
    if (value === null || value === undefined || isNaN(value)) return "N/A";
    return (value * 100).toFixed(2) + "%";
}

export function formatValue(value, isCurrency = false) {
    if (value === null || value === undefined || isNaN(value)) return "N/A";
    if (isCurrency) {
        const idrValue = value * USD_TO_IDR;
        if (Math.abs(idrValue) >= 1.0e12) return "Rp " + (idrValue / 1.0e12).toFixed(2) + "T";
        if (Math.abs(idrValue) >= 1.0e9) return "Rp " + (idrValue / 1.0e9).toFixed(2) + "B";
        if (Math.abs(idrValue) >= 1.0e6) return "Rp " + (idrValue / 1.0e6).toFixed(2) + "M";
        return "Rp " + idrValue.toLocaleString("id-ID");
    }
    return typeof value.toFixed === 'function' ? value.toFixed(2) : value;
}


// --- FUNGSI INTI APLIKASI ---

async function checkApiConnection() {
  try {
    const response = await fetch(`${API_BASE_URL}/health`);
    const statusEl = document.getElementById("api-status");
    if (response.ok) {
      statusEl.innerHTML = "🟢 Connected";
    } else {
      throw new Error("API not responding");
    }
  } catch (error) {
    document.getElementById("api-status").innerHTML = "🔴 Disconnected";
    const container = document.getElementById("content-container");
    if (container) {
        container.innerHTML = `<div class="error-message">❌ Cannot connect to backend API. Please ensure the backend server is running.</div>`;
    }
  }
}

async function showSection(section) {
  // 1. Tampilkan loading & update UI navigasi
  showLoading(true);
  document.querySelectorAll(".sidebar-item").forEach((item) => item.classList.remove("active"));
  const activeLink = document.querySelector(`[onclick*="showSection('${section}')"]`);
  if (activeLink) {
    activeLink.closest(".sidebar-item").classList.add("active");
  }
  document.getElementById("page-title").textContent = pageTitles[section] || "Dashboard";

  try {
    // 2. Ambil konten HTML dari file parsial
    const response = await fetch(`./sections/${section}.html`);
    if (!response.ok) throw new Error(`Section HTML not found: ${section}.html`);
    const htmlContent = await response.text();
    document.getElementById("content-container").innerHTML = htmlContent;

    // 3. Impor modul JavaScript yang sesuai secara dinamis
    // Ini memastikan HTML sudah ada di DOM sebelum JS dieksekusi
    const module = await import(`./${section}.js`);
    if (module.init) {
      // 4. Jalankan fungsi inisialisasi dari modul yang dimuat
      module.init();
    }
  } catch (error) {
    console.error(`Error loading section '${section}':`, error);
    document.getElementById("content-container").innerHTML = 
        `<div class="error-message">❌ Failed to load section: ${section}. Please check the console for details.</div>`;
  } finally {
    showLoading(false);
  }
}

// Ekstrak fungsi navigasi ke window object agar bisa diakses oleh `onclick` di HTML
window.showSection = showSection;

// --- INISIALISASI SAAT HALAMAN DIMUAT ---
document.addEventListener("DOMContentLoaded", async () => {
  await checkApiConnection();
  // Muat seksi 'home' sebagai default saat aplikasi pertama kali berjalan
  if (document.getElementById("api-status").innerHTML.includes("Connected")) {
      showSection("home");
  }
});