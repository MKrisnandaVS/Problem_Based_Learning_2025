// js/home.js

// Impor fungsi dan konfigurasi yang dibutuhkan dari core.js
import { config, showLoading, formatPriceIndonesian, formatValue, formatVolume, formatPercentage } from './core.js';

// --- STATE DAN VARIABEL KHUSUS HALAMAN HOME ---
let charts = {};
let currentPage = 1;
let rowsPerPage = 25;
let totalRows = 0;
let allPriceData = [];
let currentTicker = "";
let isLoadingMore = false;

// --- FUNGSI-FUNGSI LOGIKA HALAMAN HOME ---

async function loadData() {
    const tickerInput = document.getElementById("ticker-search");
    if (!tickerInput) return; // Guard clause
    
    const ticker = tickerInput.value.trim().toUpperCase() || "";
    if (currentTicker === ticker && allPriceData.length > 0) return; // Jangan load ulang data yang sama

    currentTicker = ticker;
    showLoading(true);

    // Reset state
    currentPage = 1;
    allPriceData = [];
    const statusContainer = document.getElementById("connection-status");
    if (statusContainer) statusContainer.innerHTML = "";

    try {
        const companyResponse = await fetch(`${config.API_BASE_URL}/company/${ticker}`);
        if (!companyResponse.ok) throw new Error(`Error fetching company data for ${ticker}. Ticker may not be valid.`);
        const companyData = await companyResponse.json();

        await loadPriceData(ticker, true);

        // Update semua elemen UI
        updateQuickStats(companyData, allPriceData);
        updateCompanyInfo(companyData.info);
        updateFinancialMetrics(companyData.finance);
        updateValuationMetrics(companyData.valuation);
        updateGrowthMetrics(companyData.growth);
        updateProfitabilityLiquidity(companyData.profitabilities, companyData.liquidity);
        
        // Perbaikan: Pastikan data ada sebelum membuat chart
        if (allPriceData.length > 0) {
            updatePriceChart(allPriceData.slice(0, 30));
            updateVolumeChart(allPriceData.slice(0, 30));
        }
        updatePriceTable();

    } catch (error) {
        console.error("Error loading data:", error);
        if (statusContainer) {
            statusContainer.innerHTML = `<div class="error-message">❌ ${error.message}</div>`;
        }
    } finally {
        showLoading(false);
    }
}

async function loadPriceData(ticker, isInitial = false) {
  try {
    const limit = isInitial ? 100 : 50;
    const offset = isInitial ? 0 : allPriceData.length;

    const priceResponse = await fetch(`${config.API_BASE_URL}/stock-prices/${ticker}?limit=${limit}&offset=${offset}&timeframe=1d`);
    if (!priceResponse.ok) throw new Error(`Error fetching price data: ${priceResponse.statusText}`);
    const priceData = await priceResponse.json();

    if (isInitial) {
      allPriceData = priceData;
    } else {
      allPriceData = [...allPriceData, ...priceData];
    }
    totalRows = allPriceData.length;

    const loadMoreBtn = document.getElementById("load-more-btn");
    if (loadMoreBtn) {
        loadMoreBtn.style.display = priceData.length < limit ? 'none' : 'block';
    }
    return priceData;
  } catch (error) {
    console.error("Error loading price data:", error);
    throw error;
  }
}

function updatePriceTable() {
    const tableBody = document.getElementById("price-table-body");
    if (!tableBody || !allPriceData || allPriceData.length === 0) {
        if (tableBody) tableBody.innerHTML = `<tr><td colspan="7" class="px-6 py-4 text-center text-gray-500">No price data available for this ticker.</td></tr>`;
        updatePaginationInfo();
        return;
    }

    const startIndex = (currentPage - 1) * rowsPerPage;
    const pageData = allPriceData.slice(startIndex, startIndex + rowsPerPage);
    let html = "";

    pageData.forEach((price, index) => {
        const prevIndex = startIndex + index + 1;
        const prevPrice = prevIndex < allPriceData.length ? allPriceData[prevIndex] : null;
        const change = prevPrice ? ((price.close - prevPrice.close) / prevPrice.close) * 100 : 0;
        const date = new Date(price.datetime).toLocaleDateString("en-GB");

        html += `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">${date}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">Rp ${formatPriceIndonesian(price.open * config.USD_TO_IDR)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600">Rp ${formatPriceIndonesian(price.high * config.USD_TO_IDR)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-red-600">Rp ${formatPriceIndonesian(price.low * config.USD_TO_IDR)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold">Rp ${formatPriceIndonesian(price.close * config.USD_TO_IDR)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">${formatVolume(price.volume)}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <span class="px-2 py-1 rounded-full text-xs font-medium ${change >= 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}">
                        ${change >= 0 ? "+" : ""}${change.toFixed(2)}%
                    </span>
                </td>
            </tr>
        `;
    });
    tableBody.innerHTML = html;
    updatePaginationInfo();
}


function updateQuickStats(companyData, priceData) {
    document.getElementById("market-cap-display").textContent = formatValue(companyData.finance?.marketcap, true);
    const currentPrice = priceData.length > 0 ? priceData[0].close : 0;
    document.getElementById("current-price-display").textContent = `Rp ${formatPriceIndonesian(currentPrice * config.USD_TO_IDR)}`;
    document.getElementById("pe-ratio-display").textContent = companyData.valuation?.trailingpe ? companyData.valuation.trailingpe.toFixed(1) : "N/A";
    const volume = priceData.length > 0 ? priceData[0].volume : 0;
    document.getElementById("volume-display").textContent = formatVolume(volume);
}

function updateCompanyInfo(info) {
    const container = document.getElementById("company-info");
    if (!info) {
        container.innerHTML = `<p class="text-red-500">No company info available</p>`;
        return;
    }
    container.innerHTML = `
        <div class="space-y-2">
            <h4 class="font-semibold">${info.longname || "N/A"}</h4>
            <p class="text-sm text-gray-600">${info.sector || "N/A"} | ${info.industry || "N/A"}</p>
            <p class="text-sm">${info.longbusinesssummary ? info.longbusinesssummary.substring(0, 200) + "..." : "No summary available"}</p>
            <div class="mt-2 text-sm"><strong>Website:</strong> <a href="${info.website}" target="_blank" class="text-blue-600">${info.website || "N/A"}</a></div>
        </div>`;
}

// ... Tambahkan fungsi update UI lainnya (updateFinancialMetrics, dll) di sini ...
// (Sama seperti implementasi sebelumnya, pastikan menggunakan fungsi format dari core.js)
function updateFinancialMetrics(finance) {
  const container = document.getElementById("financial-metrics");
  if (!finance) {
    container.innerHTML = `<p class="text-red-500">No financial data available</p>`;
    return;
  }
  container.innerHTML = `<div class="space-y-3 text-sm">
    <div class="flex justify-between"><span>Market Cap:</span><span class="font-semibold">${formatValue(finance.marketcap, true)}</span></div>
    <div class="flex justify-between"><span>Total Revenue:</span><span class="font-semibold">${formatValue(finance.totalrevenue, true)}</span></div>
    <div class="flex justify-between"><span>Net Income:</span><span class="font-semibold">${formatValue(finance.netincometocommon, true)}</span></div>
    <div class="flex justify-between"><span>Profit Margin:</span><span class="font-semibold">${formatPercentage(finance.profitmargins)}</span></div>
    </div>`;
}
function updateValuationMetrics(valuation) {
  const container = document.getElementById("valuation-metrics");
   if (!valuation) {
    container.innerHTML = `<p class="text-red-500">No valuation data available</p>`;
    return;
  }
   container.innerHTML = `<div class="space-y-3 text-sm">
    <div class="flex justify-between"><span>P/E Ratio:</span><span class="font-semibold">${formatValue(valuation.trailingpe)}</span></div>
    <div class="flex justify-between"><span>Forward P/E:</span><span class="font-semibold">${formatValue(valuation.forwardpe)}</span></div>
    <div class="flex justify-between"><span>PEG Ratio:</span><span class="font-semibold">${formatValue(valuation.pegratio)}</span></div>
    <div class="flex justify-between"><span>Price/Book:</span><span class="font-semibold">${formatValue(valuation.pricetobook)}</span></div>
    </div>`;
}
function updateGrowthMetrics(growth) {
    const container = document.getElementById("growth-metrics");
     if (!growth) {
        container.innerHTML = `<p class="text-red-500">No growth data available</p>`;
        return;
    }
    container.innerHTML = `<div class="space-y-3 text-sm">
        <div class="flex justify-between"><span>Revenue Growth:</span><span class="font-semibold">${formatPercentage(growth.revenuegrowth)}</span></div>
        <div class="flex justify-between"><span>Earnings Growth:</span><span class="font-semibold">${formatPercentage(growth.earningsgrowth)}</span></div>
        <div class="flex justify-between"><span>Quarterly Earnings Growth:</span><span class="font-semibold">${formatPercentage(growth.earningsquarterlygrowth)}</span></div>
    </div>`;
}
function updateProfitabilityLiquidity(profitabilities, liquidity) {
    const container = document.getElementById("profitability-liquidity");
     if (!profitabilities && !liquidity) {
        container.innerHTML = `<p class="text-red-500">No profitability or liquidity data available</p>`;
        return;
    }
    container.innerHTML = `<div class="space-y-3 text-sm">
        <div class="flex justify-between"><span>Return on Equity:</span><span class="font-semibold">${formatPercentage(profitabilities?.returnonequity)}</span></div>
        <div class="flex justify-between"><span>Current Ratio:</span><span class="font-semibold">${formatValue(liquidity?.currentratio)}</span></div>
        <div class="flex justify-between"><span>Debt to Equity:</span><span class="font-semibold">${formatValue(liquidity?.debttoequity)}</span></div>
    </div>`;
}

// --- FUNGSI PAGINASI ---
function updatePaginationInfo() {
    const totalPages = Math.ceil(totalRows / rowsPerPage);
    document.getElementById("pagination-info").textContent = `Showing ${Math.min((currentPage - 1) * rowsPerPage + 1, totalRows)} to ${Math.min(currentPage * rowsPerPage, totalRows)} of ${totalRows}`;
    document.getElementById("page-info").textContent = `Page ${currentPage} of ${totalPages || 1}`;
    document.getElementById("prev-btn").disabled = currentPage === 1;
    document.getElementById("next-btn").disabled = currentPage === totalPages || totalPages === 0;
}
function changeRowsPerPage() {
    rowsPerPage = parseInt(document.getElementById("rows-per-page").value, 10);
    currentPage = 1;
    updatePriceTable();
}
function previousPage() { if (currentPage > 1) { currentPage--; updatePriceTable(); } }
function nextPage() { if (currentPage < Math.ceil(totalRows / rowsPerPage)) { currentPage++; updatePriceTable(); } }

// --- FUNGSI CHART (KRUSIAL) ---
function updatePriceChart(data) {
    const canvas = document.getElementById("price-chart");
    if (!canvas) return; // Guard clause
    const ctx = canvas.getContext("2d");

    if (charts.priceChart) charts.priceChart.destroy();
    
    const sortedData = [...data].sort((a, b) => new Date(a.datetime) - new Date(b.datetime));

    charts.priceChart = new Chart(ctx, {
        type: "line",
        data: {
            labels: sortedData.map(d => new Date(d.datetime).toLocaleDateString("en-GB")),
            datasets: [{
                label: "Close Price (IDR)",
                data: sortedData.map(d => d.close * config.USD_TO_IDR),
                borderColor: "rgb(99, 102, 241)",
                backgroundColor: "rgba(99, 102, 241, 0.1)",
                tension: 0.4,
                fill: true,
                pointRadius: 1,
                pointHoverRadius: 5,
            }],
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { ticks: { callback: (value) => "Rp " + formatPriceIndonesian(value) } } }
        }
    });
}

function updateVolumeChart(data) {
    const canvas = document.getElementById("volume-chart");
    if (!canvas) return; // Guard clause
    const ctx = canvas.getContext("2d");

    if (charts.volumeChart) charts.volumeChart.destroy();

    const sortedData = [...data].sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
    
    charts.volumeChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: sortedData.map(d => new Date(d.datetime).toLocaleDateString("en-GB")),
            datasets: [{
                label: "Volume",
                data: sortedData.map(d => d.volume),
                backgroundColor: sortedData.map(d => d.close >= (sortedData[sortedData.indexOf(d)-1]?.close || d.close) ? 'rgba(34, 197, 94, 0.6)' : 'rgba(239, 68, 68, 0.6)'),
            }],
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { ticks: { callback: (value) => formatVolume(value) } } }
        }
    });
}

// --- FUNGSI INISIALISASI MODUL ---
export function init() {
    console.log("Home module initialized.");

    // Ikat event listener ke elemen yang ada di dalam home.html
    document.getElementById("refresh-button").onclick = loadData;
    document.getElementById("ticker-search").addEventListener("keypress", (e) => {
        if (e.key === 'Enter') loadData();
    });
    
    // pagination
    document.getElementById("rows-per-page").onchange = changeRowsPerPage;
    document.getElementById("prev-btn").onclick = previousPage;
    document.getElementById("next-btn").onclick = nextPage;
    
    // Muat data default
    document.getElementById("ticker-search").value = "";
    loadData();
}