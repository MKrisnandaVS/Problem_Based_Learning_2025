# File: backend_api.py

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from pydantic import BaseModel
import os
from datetime import datetime
from supabase import create_client, Client
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Advanced Stock Market Analytics API",
    description="Backend API for stock market analysis with real database integration",
    version="2.0.0"
)

# Middleware CORS ini sangat penting agar frontend (yang berjalan di browser)
# diizinkan untuk meminta data dari backend ini.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Mengizinkan semua asal, cocok untuk pengembangan lokal
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Fungsi untuk setup koneksi ke Supabase
def get_supabase_client() -> Client:
    supabase_url = os.getenv("SUPABASE_URL", "https://nimmziebqmbzxexlpbpm.supabase.co")
    supabase_key = os.getenv("SUPABASE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5pbW16aWVicW1ienhleGxwYnBtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQwOTI4MjUsImV4cCI6MjA1OTY2ODgyNX0.IKkJGU4chXYSphsCkmZeiQsexMcOdMUD_QgKCh11TX8")
    
    if not supabase_url or not supabase_key:
        raise HTTPException(status_code=500, detail="Supabase credentials not configured")
    
    return create_client(supabase_url, supabase_key)

# Pydantic models untuk struktur data response API
class StockPrice(BaseModel):
    datetime: datetime
    ticker: str
    open: float
    high: float
    low: float
    close: float
    volume: int
    timeframe: Optional[str] = None

class CompanyInfo(BaseModel):
    ticker: str
    address1: Optional[str] = None
    sector: Optional[str] = None
    website: Optional[str] = None
    phone: Optional[str] = None
    longname: Optional[str] = None
    longbusinesssummary: Optional[str] = None

class CompanyFinance(BaseModel):
    ticker: str
    marketcap: Optional[float] = None
    shareoutstanding: Optional[float] = None
    totalrevenue: Optional[float] = None
    netincometocommon: Optional[float] = None
    profitmargins: Optional[float] = None
    trailingeps: Optional[float] = None
    forwardeps: Optional[float] = None
    grossmargins: Optional[float] = None
    operatingmargins: Optional[float] = None
    operatingcashflow: Optional[float] = None
    freecashflow: Optional[float] = None

class CompanyValuation(BaseModel):
    ticker: str
    trailingpe: Optional[float] = None
    forwardpe: Optional[float] = None
    pegratio: Optional[float] = None
    pricetobook: Optional[float] = None
    pricetosalestrailing12months: Optional[float] = None

class CompanyDividend(BaseModel):
    ticker: str
    dividendrate: Optional[float] = None
    dividendyield: Optional[float] = None
    exdividenddate: Optional[str] = None
    payoutratio: Optional[float] = None

class CompanyGrowth(BaseModel):
    ticker: str
    revenuegrowth: Optional[float] = None
    earningsgrowth: Optional[float] = None
    earningsquarterlygrowth: Optional[float] = None

class CompanyProfitabilities(BaseModel):
    ticker: str
    returnonequity: Optional[float] = None
    returnonassets: Optional[float] = None

class CompanyLiquidity(BaseModel):
    ticker: str
    totalcash: Optional[float] = None
    totaldebt: Optional[float] = None
    debttoequity: Optional[float] = None
    currentratio: Optional[float] = None

# API Endpoints

@app.get("/")
async def root():
    return {
        "message": "Stock Market Analytics API",
        "version": "2.0.0",
        "docs": "/docs",
        "status": "active"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

@app.get("/stock-prices/{ticker}", response_model=List[StockPrice])
async def get_stock_price_by_ticker(
    ticker: str,
    timeframe: Optional[str] = None,
    limit: int = 100,
    supabase: Client = Depends(get_supabase_client)
):
    query = supabase.table("stock_prices").select("*").eq("ticker", ticker)
    if timeframe:
        query = query.eq("timeframe", timeframe)
    query = query.order("datetime", desc=True).limit(limit)
    response = query.execute()
    
    if hasattr(response, "error") and response.error:
        raise HTTPException(status_code=500, detail=f"Database error: {response.error}")
    if not response.data:
        raise HTTPException(status_code=404, detail=f"No stock prices found for ticker {ticker}")
    return response.data

@app.get("/company/{ticker}")
async def get_comprehensive_company_data(
    ticker: str,
    supabase: Client = Depends(get_supabase_client)
):
    # Mengambil semua data relevan untuk satu ticker secara bersamaan
    info_response = supabase.table("company_info").select("*").eq("ticker", ticker).execute()
    finance_response = supabase.table("company_finance").select("*").eq("ticker", ticker).execute()
    valuation_response = supabase.table("company_valuation").select("*").eq("ticker", ticker).execute()
    dividend_response = supabase.table("company_dividend").select("*").eq("ticker", ticker).execute()
    growth_response = supabase.table("company_growth").select("*").eq("ticker", ticker).execute()
    profitabilities_response = supabase.table("company_profitabilities").select("*").eq("ticker", ticker).execute()
    liquidity_response = supabase.table("company_liquidity").select("*").eq("ticker", ticker).execute()
    
    responses = [info_response, finance_response, valuation_response, dividend_response, growth_response, profitabilities_response, liquidity_response]
    for response in responses:
        if hasattr(response, "error") and response.error:
            raise HTTPException(status_code=500, detail=f"Database error: {response.error}")
    
    # Menggabungkan hasil dalam satu JSON object
    result = {
        "ticker": ticker,
        "info": info_response.data[0] if info_response.data else None,
        "finance": finance_response.data[0] if finance_response.data else None,
        "valuation": valuation_response.data[0] if valuation_response.data else None,
        "dividend": dividend_response.data[0] if dividend_response.data else None,
        "growth": growth_response.data[0] if growth_response.data else None,
        "profitabilities": profitabilities_response.data[0] if profitabilities_response.data else None,
        "liquidity": liquidity_response.data[0] if liquidity_response.data else None
    }
    return result

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting Stock Analytics Backend API...")
    print("📊 API available at: http://localhost:8000")
    print("📚 API Documentation: http://localhost:8000/docs")
    print("💾 Using Supabase database for data")
    uvicorn.run(app, host="0.0.0.0", port=8000)